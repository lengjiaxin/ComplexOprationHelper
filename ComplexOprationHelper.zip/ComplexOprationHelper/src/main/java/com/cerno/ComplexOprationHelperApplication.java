package com.cerno;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ComplexOprationHelperApplication {

	public static void main(String[] args) {
		SpringApplication.run(ComplexOprationHelperApplication.class, args);
	}

}
